// =====================================================================
//  固高 GTS/GTN 系列 适配器（gts.dll）
//  生成工具: 上位机代码工厂 v1.0 | 2026-10-20 00:17:00
//  KB级别: B —— 核心API已映射(Open/使能/回零/点位/IO/位置)，插补为等时点位法+升级路径注释。
//  上真机前按 docs/ApiChecklist.md 核对签名（标注 [核对] 处）
// =====================================================================
using System;
using System.Runtime.InteropServices;
using System.Threading;
using MotionControl.Core;

namespace MotionControl.Adapters.Googol
{
    /// <summary>
    /// 固高 GTS/GTN 系列 —— IMotionController 适配器。
    /// 设计要点（JD职责3）:
    ///   1. P/Invoke 封装 + 签名核对标记
    ///   2. 单位换算: 用户单位(mm) <-脉冲- gts.dll
    ///   3. SDK 调用统一持锁串行化（厂商库多非线程安全）
    ///   4. 错误码统一映射 MotionResult
    /// </summary>
    public class GoogolGtsController : IMotionController
    {
        private readonly object _sdk = new object();
        private ControllerConnectInfo _info;
        private bool _open;
        private readonly bool[] _homed = new bool[8];
        private readonly double[] _ppu = new double[8];         // 脉冲/用户单位
        private readonly HomeMode[] _homeMode = new HomeMode[8];
        private readonly double[] _homeVelFast = new double[8];
        private readonly double[] _homeVelSlow = new double[8];
        private readonly double[] _homeAcc = new double[8];
        private readonly bool[] _homing = new bool[8];
        private readonly int[] _homeStartT = new int[8];
        private readonly double[] _softNeg = new double[8];
        private readonly double[] _softPos = new double[8];

        private readonly short[] _gtsHomeMode = new short[8];

        public GoogolGtsController()
        {
            for (int i = 0; i < 8; i++) { _ppu[i] = 10000; _softNeg[i] = -100000; _softPos[i] = 100000; _homeVelFast[i] = 20; _homeVelSlow[i] = 2; _homeAcc[i] = 200; }

            _gtsHomeMode[0] = 2; for (int i = 1; i < 8; i++) _gtsHomeMode[i] = 2;
        }

        public Brand Brand { get { return Brand.GoogolGts; } }
        public string DeviceName { get { return "GoogolGTS"; } }
        public bool IsOpen { get { return _open; } }

        #region 厂商 API 导入（[核对] = 签名需按手册确认）

        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_Open(short card, short channel);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_Close();
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_Reset();
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
        private static extern short GT_LoadConfig([MarshalAs(UnmanagedType.LPStr)] string cfgFile);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_ClrSts(short axis);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_AxisOn(short axis);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_AxisOff(short axis);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_Stop(int mask, int option);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_SetPos(short axis, int pos);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_SetVel(short axis, double vel);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_Update(int mask);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_PrfTrap(short axis);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_SetTrapPara(short axis, ref TTrapPrfPara p);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_PrfJog(short axis);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_SetJogPara(short axis, ref TJogPrfPara p);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_GoHome(short axis);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_SetGoHomePara(short axis, ref TGoHomePara p);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_GetSts(short axis, out int pSts, short count, out uint pClock);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_GetPrfPos(short axis, out double pPos, int count, out uint pClock);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_GetEncPos(short axis, out double pPos, int count, out uint pClock);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_GetDi(short type, out int pDi);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_SetDo(short type, short idx, short value);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_GetAi(short idx, out double pValue);
        [DllImport("gts.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern short GT_SetAo(short idx, double value);

        // [核对] 结构体字段顺序以手册为准（版本间存在差异）
        [StructLayout(LayoutKind.Sequential)]
        public struct TTrapPrfPara
        {
            public double acc;
            public double dec;
            public double smoothTime;   // S曲线平滑时间(0=梯形)
            public double vel;
            public double vel_start;
        }
        [StructLayout(LayoutKind.Sequential)]
        public struct TJogPrfPara
        {
            public double acc;
            public double dec;
            public double smoothTime;
            public double vel;
        }
        [StructLayout(LayoutKind.Sequential)]
        public struct TGoHomePara
        {
            public short mode;
            public double velHigh;
            public double velLow;
            public double acc;
            public double dec;
        }
        #endregion

        public MotionResult Open(ControllerConnectInfo info)
        {
            lock (_sdk)
            {
                if (_open) return MotionResult.Success("already open");
                _info = info;

                short rc = GT_Open(info.CardNo, 0);
                if (rc != 0) return MotionResult.Fail(rc, "GT_Open card=" + info.CardNo);
                GT_Reset();
                if (!string.IsNullOrEmpty(info.ConfigFile))
                {
                    rc = GT_LoadConfig(info.ConfigFile);
                    if (rc != 0) { GT_Close(); return MotionResult.Fail(rc, "GT_LoadConfig " + info.ConfigFile); }
                }
                _open = true;
                return MotionResult.Success("GoogolGTS opened");
            }
        }

        public MotionResult Close()
        {
            lock (_sdk)
            {
                if (!_open) return MotionResult.Success();

                GT_Reset();
                GT_Close();
                _open = false;
                return MotionResult.Success();
            }
        }

        public void Dispose() { try { Close(); } catch { } }

        public MotionResult ConfigureAxis(AxisConfig cfg)
        {
            lock (_sdk)
            {
                if (cfg == null) return MotionResult.Fail(-6, "null config");
                if (cfg.AxisIndex < 0 || cfg.AxisIndex > 7) return MotionResult.Fail(-7, "axis out of range 0-7");
                int i = cfg.AxisIndex;
                _ppu[i] = cfg.PulsesPerUnit <= 0 ? 10000 : cfg.PulsesPerUnit;
                _homeMode[i] = cfg.Home.Mode; _homeVelFast[i] = cfg.Home.VelFast;
                _homeVelSlow[i] = cfg.Home.VelSlow; _homeAcc[i] = cfg.Home.Acc;
                _softNeg[i] = cfg.SoftLimitNeg; _softPos[i] = cfg.SoftLimitPos;
                _homed[i] = false;

                _gtsHomeMode[i] = MapHomeModeToGts(cfg.Home.Mode);
                return MotionResult.Success(cfg + " configured");
            }
        }

        public MotionResult Enable(int axis, bool on)
        {
            lock (_sdk)
            {
                if (!_open) return MotionResult.Fail(-1, "not open");
                CheckRange(axis);

                short ax = Ax(axis);
                short rc = GT_ClrSts(ax);
                rc = on ? GT_AxisOn(ax) : GT_AxisOff(ax);
                if (rc != 0) return MotionResult.Fail(rc, "GT_Axis" + (on ? "On" : "Off") + " axis " + axis);
                return MotionResult.Success();
            }
        }

        public AxisState GetState(int axis)
        {
            lock (_sdk)
            {
                if (!_open) return AxisState.None;
                CheckRange(axis);

                int sts; uint clk;
                short rc = GT_GetSts(Ax(axis), out sts, 1, out clk);
                AxisState s = AxisState.None;
                if (rc == 0)
                {
                    if ((sts & 0x1) != 0) s |= AxisState.Enabled;     // [核对] 使能位
                    if ((sts & 0x400) != 0) s |= AxisState.Moving;    // [核对] 运动位(常见bit10)
                    if ((sts & 0x2) != 0) s |= AxisState.Alarm;       // [核对] 报警位
                    if ((sts & 0x20) != 0) s |= AxisState.LimitPos;   // [核对] 正限位
                    if ((sts & 0x10) != 0) s |= AxisState.LimitNeg;   // [核对] 负限位
                    if (_homed[axis]) s |= AxisState.Homed;
                }
                return s;
            }
        }

        public double GetCommandPos(int axis)
        {
            lock (_sdk)
            {
                if (!_open) return 0;
                CheckRange(axis);

                double pos; uint clk;
                short rc = GT_GetPrfPos(Ax(axis), out pos, 1, out clk);
                return rc == 0 ? pos / _ppu[axis] : 0;
            }
        }

        public double GetFeedbackPos(int axis)
        {
            lock (_sdk)
            {
                if (!_open) return 0;
                CheckRange(axis);

                double pos; uint clk;
                short rc = GT_GetEncPos(Ax(axis), out pos, 1, out clk);
                return rc == 0 ? pos / _ppu[axis] : GetCommandPos(axis);
            }
        }

        public double GetFollowingError(int axis)
        {
            lock (_sdk)
            {
                if (!_open) return 0;
                double cmd = GetCommandPos(axis); double fb = GetFeedbackPos(axis);
                return cmd - fb;
            }
        }

        public MotionResult Home(int axis)
        {
            lock (_sdk)
            {
                if (!_open) return MotionResult.Fail(-1, "not open");
                CheckRange(axis); _homed[axis] = false; _homing[axis] = true; _homeStartT[axis] = Environment.TickCount;

                short ax = Ax(axis);
                TGoHomePara hp = new TGoHomePara();
                hp.mode = MapHomeMode(axis);          // [核对] 模式字映射
                hp.velHigh = _homeVelFast[axis] * _ppu[axis];
                hp.velLow = _homeVelSlow[axis] * _ppu[axis];
                hp.acc = _homeAcc[axis] * _ppu[axis];
                hp.dec = _homeAcc[axis] * _ppu[axis];
                short rc = GT_SetGoHomePara(ax, ref hp);
                if (rc != 0) return MotionResult.Fail(rc, "GT_SetGoHomePara");
                rc = GT_GoHome(ax);
                if (rc != 0) return MotionResult.Fail(rc, "GT_GoHome");
                return MotionResult.Success("homing started");
            }
        }

        public bool IsHomed(int axis) { lock (_sdk) { return axis >= 0 && axis < 8 && _homed[axis]; } }

        public MotionResult WaitHomeDone(int axis, int timeoutMs)
        {
            DateTime t0 = DateTime.Now;
            while ((DateTime.Now - t0).TotalMilliseconds < timeoutMs)
            {
                lock (_sdk)
                {
                    if (!_open) return MotionResult.Fail(-1, "not open");
                    if (_homing[axis] && Environment.TickCount - _homeStartT[axis] > 200 && (!IsMovingGts(axis))) { _homing[axis] = false; _homed[axis] = true; return MotionResult.Success(); }
                }
                Thread.Sleep(10);
            }
            return MotionResult.Fail(-2, "home timeout axis " + axis);
        }

        public MotionResult MoveTo(int axis, double posUser, MoveParams p, MoveMode mode)
        {
            lock (_sdk)
            {
                if (!_open) return MotionResult.Fail(-1, "not open");
                CheckRange(axis);
                double from = GetCommandPos(axis);
                double to = (mode == MoveMode.Absolute) ? posUser : from + posUser;
                if (to < _softNeg[axis] || to > _softPos[axis])
                    return MotionResult.Fail(-100, "soft limit reject: target " + to.ToString("F3"));

                short ax = Ax(axis);
                short rc = GT_PrfTrap(ax);
                if (rc != 0) return MotionResult.Fail(rc, "GT_PrfTrap");
                TTrapPrfPara tp = new TTrapPrfPara();
                tp.acc = p.Acc * _ppu[axis];
                tp.dec = p.Dec * _ppu[axis];
                tp.smoothTime = p.JerkRatio > 0 ? 0.02 + p.JerkRatio * 0.1 : 0;  // [核对] S曲线平滑时间
                tp.vel = Math.Abs(p.Vel) * _ppu[axis];
                tp.vel_start = 0;
                rc = GT_SetTrapPara(ax, ref tp);
                if (rc != 0) return MotionResult.Fail(rc, "GT_SetTrapPara");
                rc = GT_SetPos(ax, (int)Math.Round(to * _ppu[axis]));
                if (rc != 0) return MotionResult.Fail(rc, "GT_SetPos");
                rc = GT_SetVel(ax, Math.Abs(p.Vel) * _ppu[axis]);
                if (rc != 0) return MotionResult.Fail(rc, "GT_SetVel");
                rc = GT_Update(1 << axis);   // [核对] 掩码bit为0-based轴号
                if (rc != 0) return MotionResult.Fail(rc, "GT_Update");
                return MotionResult.Success();
            }
        }

        public MotionResult MoveJog(int axis, double velUserPerSec, MoveParams p)
        {
            lock (_sdk)
            {
                if (!_open) return MotionResult.Fail(-1, "not open");
                CheckRange(axis);

                short ax = Ax(axis);
                short rc = GT_PrfJog(ax);
                if (rc != 0) return MotionResult.Fail(rc, "GT_PrfJog");
                TJogPrfPara jp = new TJogPrfPara();
                jp.acc = p.Acc * _ppu[axis]; jp.dec = p.Dec * _ppu[axis];
                jp.smoothTime = 0.05;
                jp.vel = velUserPerSec * _ppu[axis];   // 符号即方向
                rc = GT_SetJogPara(ax, ref jp);
                if (rc != 0) return MotionResult.Fail(rc, "GT_SetJogPara");
                rc = GT_Update(1 << axis);
                if (rc != 0) return MotionResult.Fail(rc, "GT_Update");
                return MotionResult.Success("jog vel=" + velUserPerSec.ToString("F2"));
            }
        }

        public MotionResult Stop(int axis, bool emergency)
        {
            lock (_sdk)
            {
                if (!_open) return MotionResult.Fail(-1, "not open");
                CheckRange(axis);

                int mask = 1 << axis;
                short rc = GT_Stop(mask, emergency ? 1 : 0);
                if (rc != 0) return MotionResult.Fail(rc, "GT_Stop");
                return MotionResult.Success(emergency ? "emergency stop" : "stop");
            }
        }

        public MotionResult WaitMoveDone(int axis, int timeoutMs)
        {
            DateTime t0 = DateTime.Now;
            while ((DateTime.Now - t0).TotalMilliseconds < timeoutMs)
            {
                lock (_sdk)
                {
                    if (!_open) return MotionResult.Fail(-1, "not open");
                    if (!(IsMovingGts(axis))) return MotionResult.Success();
                }
                Thread.Sleep(10);
            }
            return MotionResult.Fail(-3, "move timeout axis " + axis);
        }

        public MotionResult MoveLine(int[] axisList, double[] targetUser, MoveParams p, MoveMode mode)
        {
            lock (_sdk)
            {
                if (!_open) return MotionResult.Fail(-1, "not open");
                if (axisList == null || targetUser == null || axisList.Length != targetUser.Length)
                    return MotionResult.Fail(-4, "axisList/targetUser mismatch");

                // 等时点位法: 各轴速度按位移比例分配，同触发同到达。
                // [升级路径] 高同步要求场景改用固高坐标系插补(GT_SetCrdPrf/GT_CrdLine/GT_CrdArc)，
                //            可获得硬件级插补脉冲同步（见docs/CapabilityMatrix.md）。
                double maxDelta = 1e-9;
                double[] from = new double[axisList.Length];
                double[] toArr = new double[axisList.Length];
                for (int i = 0; i < axisList.Length; i++)
                {
                    from[i] = GetCommandPos(axisList[i]);
                    toArr[i] = (mode == MoveMode.Absolute) ? targetUser[i] : from[i] + targetUser[i];
                    double d = Math.Abs(toArr[i] - from[i]);
                    if (d > maxDelta) maxDelta = d;
                    if (toArr[i] < _softNeg[axisList[i]] || toArr[i] > _softPos[axisList[i]])
                        return MotionResult.Fail(-100, "soft limit axis " + axisList[i]);
                }
                double duration = maxDelta / Math.Max(p.Vel, 0.001) + Math.Max(p.Vel, 0.001) / Math.Max(p.Acc, 1);
                int allMask = 0;
                for (int i = 0; i < axisList.Length; i++)
                {
                    int ax0 = axisList[i];
                    short ax = Ax(ax0);
                    double dist = Math.Abs(toArr[i] - from[i]);
                    double vi = dist / Math.Max(duration, 0.001);
                    short rc = GT_PrfTrap(ax);
                    if (rc != 0) return MotionResult.Fail(rc, "GT_PrfTrap");
                    TTrapPrfPara tp = new TTrapPrfPara();
                    tp.acc = p.Acc * _ppu[ax0]; tp.dec = p.Dec * _ppu[ax0];
                    tp.smoothTime = p.JerkRatio > 0 ? 0.05 : 0;
                    tp.vel = vi * _ppu[ax0]; tp.vel_start = 0;
                    rc = GT_SetTrapPara(ax, ref tp);
                    if (rc != 0) return MotionResult.Fail(rc, "GT_SetTrapPara");
                    rc = GT_SetPos(ax, (int)Math.Round(toArr[i] * _ppu[ax0]));
                    if (rc != 0) return MotionResult.Fail(rc, "GT_SetPos");
                    rc = GT_SetVel(ax, vi * _ppu[ax0]);
                    if (rc != 0) return MotionResult.Fail(rc, "GT_SetVel");
                    allMask |= 1 << ax0;
                }
                short rcU = GT_Update(allMask);
                if (rcU != 0) return MotionResult.Fail(rcU, "GT_Update");
                return MotionResult.Success("equal-time line, axes=" + axisList.Length);
            }
        }

        public MotionResult MoveArc2D(int axisX, int axisY, double i, double j, double endX, double endY, bool cw, MoveParams p)
        {
            lock (_sdk)
            {
                if (!_open) return MotionResult.Fail(-1, "not open");
                double x0 = GetCommandPos(axisX), y0 = GetCommandPos(axisY);
                double cx = x0 + i, cy = y0 + j;
                double r = Math.Sqrt(i * i + j * j);
                if (r < 1e-9) return MotionResult.Fail(-8, "zero radius arc");
                double a0 = Math.Atan2(y0 - cy, x0 - cx);
                double a1 = Math.Atan2(endY - cy, endX - cx);
                double sweep = a1 - a0;
                if (cw && sweep >= 0) sweep -= 2 * Math.PI;
                if (!cw && sweep <= 0) sweep += 2 * Math.PI;
                int n = 32;
                for (int k = 1; k <= n; k++)
                {
                    double a = a0 + sweep * k / n;
                    MotionResult rseg = MoveLine(new int[] { axisX, axisY },
                        new double[] { cx + r * Math.Cos(a), cy + r * Math.Sin(a) }, p, MoveMode.Absolute);
                    if (!rseg.Ok) return rseg;
                    MotionResult rw = WaitMoveDone(axisX, 60000);
                    if (!rw.Ok) return rw;
                }
                // [升级路径] 硬件圆弧: GT_CrdArc（坐标系模式），精度与速度优于线性化
                return MotionResult.Success("arc done (32-seg linearization)");
            }
        }

        public MotionResult SetDo(int index, bool on)
        {
            lock (_sdk)
            {
                if (!_open) return MotionResult.Fail(-1, "not open");

                short rc = GT_SetDo(1, (short)index, (short)(on ? 1 : 0));  // [核对] type 1=GT_DO_GPO
                if (rc != 0) return MotionResult.Fail(rc, "GT_SetDo " + index);
                return MotionResult.Success();
            }
        }

        public bool GetDi(int index)
        {
            lock (_sdk)
            {
                if (!_open) return false;

                int di;
                short rc = GT_GetDi(1, out di);   // [核对] type 1=GT_DI_GPI; 返回组值则按位取
                if (rc != 0) return false;
                return ((di >> index) & 1) != 0;
            }
        }

        public double GetAi(int index)
        {
            lock (_sdk)
            {
                if (!_open) return 0;

                double v;
                short rc = GT_GetAi((short)index, out v);
                return rc == 0 ? v : 0;
            }
        }

        public MotionResult SetAo(int index, double volts)
        {
            lock (_sdk)
            {
                if (!_open) return MotionResult.Fail(-1, "not open");

                short rc = GT_SetAo((short)index, volts);   // [核对] 部分型号无AO通道
                if (rc != 0) return MotionResult.Fail(rc, "GT_SetAo " + index);
                return MotionResult.Success();
            }
        }

        public MotionResult WaitDi(int index, bool level, int timeoutMs)
        {
            DateTime t0 = DateTime.Now;
            while ((DateTime.Now - t0).TotalMilliseconds < timeoutMs)
            {
                if (GetDi(index) == level) return MotionResult.Success();
                Thread.Sleep(10);
            }
            return MotionResult.Fail(-5, "wait DI" + index + " timeout");
        }


        private short MapHomeMode(int axis)
        {
            switch (_homeMode[axis])
            {
                case HomeMode.LimitReverse: return 0;      // [核对] 限位反向
                case HomeMode.HomeSwitch: return 1;        // [核对] 原点开关
                case HomeMode.HomeSwitchIndex: return 2;   // [核对] 原点+编码器Z
                case HomeMode.IndexOnly: return 3;         // [核对] 仅Z
                default: return 2;
            }
        }
        private static short MapHomeModeToGts(HomeMode m)
        {
            switch (m)
            {
                case HomeMode.LimitReverse: return 0;
                case HomeMode.HomeSwitch: return 1;
                case HomeMode.HomeSwitchIndex: return 2;
                case HomeMode.IndexOnly: return 3;
                default: return 2;
            }
        }
        private bool IsMovingGts(int axis)
        {
            int sts; uint clk;
            if (GT_GetSts(Ax(axis), out sts, 1, out clk) != 0) return false;
            return (sts & 0x400) != 0;   // [核对] 运动位
        }
        private static void CheckRange(int axis)
        {
            if (axis < 0 || axis > 7) throw new ArgumentOutOfRangeException("axis", axis, "supports 0-7");
        }

        /// <summary>统一0-based轴号 -> 固高1-based</summary>
        private static short Ax(int axis) { return (short)(axis + 1); }
    }
}
